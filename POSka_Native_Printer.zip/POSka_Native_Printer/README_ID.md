# POSka 2.1.0 — Native Bluetooth Thermal Printer

Proyek ini membungkus HTML POSka di Android WebView dan menyediakan JavaScript bridge `window.POSkaBluetooth` untuk printer thermal Bluetooth Classic / SPP yang kompatibel ESC/POS. Tidak menggunakan RawBT.

## Build APK dari GitHub Actions
1. Buat repository GitHub baru.
2. Unggah seluruh isi folder proyek ini (bukan file ZIP di dalam folder).
3. Buka tab Actions dan jalankan workflow `Build POSka APK`.
4. Setelah selesai, unduh artifact `POSka-2.1.0-Native-Bluetooth-APK`.
5. Instal `app-debug.apk` di Android.

## Menghubungkan printer
1. Pasangkan printer dari Pengaturan Bluetooth Android terlebih dahulu.
2. Buka POSka → Pengaturan → Printer Thermal Internal POSka.
3. Berikan izin Bluetooth saat diminta.
4. Tekan Perbarui Perangkat, pilih printer, lalu Hubungkan Printer.
5. Tekan Tes Cetak.

## Batasan build awal
- Mendukung Bluetooth Classic / SPP ESC/POS. Printer BLE-only tidak didukung oleh modul ini.
- USB OTG dan Wi-Fi/LAN belum diimplementasikan pada build awal.
- Pemotong kertas otomatis dikirim sebagai perintah ESC/POS; printer tanpa auto-cutter akan mengabaikannya.
- Barcode/QR native belum diaktifkan pada build awal.
- Encoding printer generik menggunakan CP437; karakter di luar code page dapat berubah. Uji pada printer fisik sebelum operasional.
- Proyek belum dikompilasi dan diuji pada perangkat fisik dalam sesi ini.

## Catatan penting
HTML asli POSka disimpan di `app/src/main/assets/index.html`. Firebase tetap memerlukan koneksi internet. Simpan cadangan file HTML dan konfigurasi signing sebelum distribusi produksi.
