package com.poska.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 501;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private BluetoothSocket socket;
    private OutputStream output;
    private final Object printerLock = new Object();
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int REQ_FILE = 602;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("https://") || url.startsWith("http://") || url.startsWith("whatsapp://") || url.startsWith("tel:")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; }
                    catch (Exception ignored) { return false; }
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try { startActivityForResult(Intent.createChooser(intent, "Pilih file"), REQ_FILE); }
                catch (Exception e) { fileChooserCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new PrinterBridge(), "POSkaBluetooth");
        webView.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermission();
    }

    private void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_BT && webView != null) {
            webView.post(() -> webView.evaluateJavascript("if(window.refreshPrinterDevices) refreshPrinterDevices();", null));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileChooserCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileChooserCallback.onReceiveValue(result);
            fileChooserCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        closePrinter();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private void closePrinter() {
        synchronized (printerLock) {
            try { if (output != null) output.close(); } catch (Exception ignored) {}
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            output = null; socket = null;
        }
    }

    private class PrinterBridge {
        @JavascriptInterface public String getPairedDevices() {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return "[]";
                }
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null || !adapter.isEnabled()) return "[]";
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                JSONArray array = new JSONArray();
                for (BluetoothDevice device : devices) {
                    JSONObject item = new JSONObject();
                    item.put("name", device.getName() == null ? "Printer Bluetooth" : device.getName());
                    item.put("address", device.getAddress());
                    array.put(item);
                }
                return array.toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public String connect(String address) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestBluetoothPermission());
                    return "ERROR: Izin Bluetooth belum diberikan. Izinkan akses Bluetooth lalu coba lagi.";
                }
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return "ERROR: Perangkat ini tidak memiliki Bluetooth.";
                if (!adapter.isEnabled()) return "ERROR: Aktifkan Bluetooth Android terlebih dahulu.";
                BluetoothDevice device = adapter.getRemoteDevice(address);
                closePrinter();
                adapter.cancelDiscovery();
                BluetoothSocket newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                newSocket.connect();
                synchronized (printerLock) {
                    socket = newSocket;
                    output = socket.getOutputStream();
                }
                return "OK: Terhubung ke " + (device.getName() == null ? address : device.getName());
            } catch (Exception e) {
                closePrinter();
                return "ERROR: Tidak dapat terhubung. Pastikan printer mendukung Bluetooth Classic SPP dan sudah dipasangkan. " + safe(e);
            }
        }

        @JavascriptInterface public String print(String text, int paperWidth) {
            synchronized (printerLock) {
                try {
                    if (socket == null || !socket.isConnected() || output == null)
                        return "ERROR: Printer belum terhubung. Hubungkan printer terlebih dahulu.";
                    int columns = paperWidth == 58 ? 32 : 48;
                    byte[] init = new byte[]{0x1B, 0x40};
                    output.write(init);
                    output.write(new byte[]{0x1B, 0x61, 0x00});
                    String normalized = String.valueOf(text == null ? "" : text)
                        .replace("\r\n", "\n").replace("\r", "\n");
                    // ESC/POS printer generik umumnya mendukung ASCII; karakter di luar CP437 diganti aman.
                    Charset cp437 = Charset.forName("CP437");
                    output.write(normalized.getBytes(cp437));
                    output.write(new byte[]{0x0A,0x0A,0x0A});
                    // Full cut; printer yang tidak memiliki cutter akan mengabaikan perintah ini.
                    output.write(new byte[]{0x1D,0x56,0x00});
                    output.flush();
                    return "OK: Data cetak terkirim (" + columns + " kolom).";
                } catch (Exception e) {
                    closePrinter();
                    return "ERROR: Gagal mengirim data ke printer. " + safe(e);
                }
            }
        }

        @JavascriptInterface public void openBluetoothSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        }
        @JavascriptInterface public boolean isConnected() {
            synchronized (printerLock) { return socket != null && socket.isConnected(); }
        }
        @JavascriptInterface public void disconnect() { closePrinter(); }
    }

    private String safe(Exception e) {
        String message = e.getMessage();
        return message == null ? e.getClass().getSimpleName() : message;
    }
}
